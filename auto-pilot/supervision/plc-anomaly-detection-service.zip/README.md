# PLC Anomaly Detection (Spring Boot) — Service Pack

Pack de classes **Spring Boot / JPA** pour détecter des anomalies PLC à partir :
- des **événements PLC** (`PlcEvent`)
- du **workflow nominal** en base (tables `machine` / `production_step`)
- de l’historique pour calculer des signaux **prédictifs** : EWMA, burstiness, ratio de taux, z-score (écart-type), et un score type Hawkes (auto-excitation).

## Contenu
- `service/PlcAnomalyDetectionService.java` : orchestrateur (règles + prédictif + persistance)
- `service/WorkflowNominalService.java` : charge le workflow nominal depuis la BDD + cache
- `service/StepStatsService.java` : stats historiques (durées/intervalles, occurrences)
- `predict/*` : calculateurs EWMA / burstiness / Hawkes-like
- `rules/*` : règles déterministes (ERROR, déphasage ts, saut de step, ordre workflow)
- `repo/*` : interfaces repositories (Spring Data JPA)
- `dto/*` : records utilitaires
- `sql/*` : requêtes natives PostgreSQL

## Hypothèses minimales
- `PlcEvent` : `id`, `ts` (OffsetDateTime), `machine`, `stepId`, `stepName`, `level`, `code`, `partId`, `cycle`.
- `ProductionStep` (workflow nominal) : `machine`, `stepCode`, `name`, `nominalDurationS`, `sequenceOrder`.

## Intégration rapide
1. Copie le dossier `src/main/java/com/wacdo/supervision/...` dans ton projet.
2. Remplace les placeholders `PlcEvent` / `ProductionStep` / `Machine` / `PlcAnomaly` par tes vraies entités (ou supprime les placeholders).
3. Adapte les requêtes SQL natives dans `StepStatsService` aux noms exacts de tables/colonnes (TimescaleDB/Postgres).
4. Appelle `PlcAnomalyDetectionService.detectAndPersist(event)` sur les événements PLC pertinents.

## Notes
- Score Hawkes-like : intensité = μ + Σ α exp(-βΔt). Ultra rapide, pas de dépendance externe.
- Le service est conçu pour **ne dépendre que de la vérité nominale en BDD** (pas de “prompt magic”).
