-- Daily anomaly occurrences for EWMA series
with days as (
  select generate_series(
     date_trunc('day', :since::timestamptz),
     date_trunc('day', now()::timestamptz),
     interval '1 day'
  ) as day
),
a as (
  select date_trunc('day', ts_detected) as day, count(*) as n
  from plc_anomalies
  where machine = :machine
    and step_id = :stepId
    and ts_detected >= :since
  group by 1
)
select coalesce(a.n,0) as n
from days d
left join a on a.day = d.day
order by d.day asc;
