-- Interval stats between steps for a given machine+step_id
with e as (
  select
    ts,
    lag(ts) over (partition by part_id order by ts) as prev_ts
  from plc_events
  where machine = :machine
    and step_id = :stepId
    and ts >= :since
),
d as (
  select extract(epoch from (ts - prev_ts)) as dt_s
  from e
  where prev_ts is not null
    and ts >= prev_ts
)
select
  count(*) as n,
  avg(dt_s) as mean_s,
  stddev_samp(dt_s) as std_s,
  percentile_cont(0.95) within group (order by dt_s) as p95_s
from d;
