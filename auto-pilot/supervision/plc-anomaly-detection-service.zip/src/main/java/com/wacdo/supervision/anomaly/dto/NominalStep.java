package com.wacdo.supervision.anomaly.dto;

public record NominalStep(
        String machine,
        String stepId,
        String stepName,
        Integer orderIndex,
        Double nominalDurationS
) {}
