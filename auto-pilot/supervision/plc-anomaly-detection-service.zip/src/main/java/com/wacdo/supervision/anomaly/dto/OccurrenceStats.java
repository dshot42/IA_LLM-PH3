package com.wacdo.supervision.anomaly.dto;

public record OccurrenceStats(
        long occurrences,
        double ratePerDay
) {}
