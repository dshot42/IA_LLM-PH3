package com.wacdo.supervision.anomaly.dto;

public record PredictiveSignals(
        int windowDays,
        double ewmaRatio,
        double rateRatio,
        double burstiness,
        int hawkesScore,
        String confidence
) {}
