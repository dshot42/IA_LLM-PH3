package com.wacdo.supervision.anomaly.entity;

public class PlcAnomaly {
    private Long id;
    private String partId;
    private java.time.OffsetDateTime tsDetected;
    private Integer cycle;
    private String machine;
    private String stepId;
    private String stepName;

    private Boolean ruleAnomaly;
    private com.fasterxml.jackson.databind.JsonNode ruleReasons;

    private Boolean hasStepError = false;
    private Integer nStepErrors = 0;

    private Integer windowDays;
    private Double ewmaRatio;
    private Double rateRatio;
    private Double burstiness;
    private Integer hawkesScore;
    private String confidence;

    private String severity;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getPartId() { return partId; }
    public void setPartId(String partId) { this.partId = partId; }

    public java.time.OffsetDateTime getTsDetected() { return tsDetected; }
    public void setTsDetected(java.time.OffsetDateTime tsDetected) { this.tsDetected = tsDetected; }

    public Integer getCycle() { return cycle; }
    public void setCycle(Integer cycle) { this.cycle = cycle; }

    public String getMachine() { return machine; }
    public void setMachine(String machine) { this.machine = machine; }

    public String getStepId() { return stepId; }
    public void setStepId(String stepId) { this.stepId = stepId; }

    public String getStepName() { return stepName; }
    public void setStepName(String stepName) { this.stepName = stepName; }

    public Boolean getRuleAnomaly() { return ruleAnomaly; }
    public void setRuleAnomaly(Boolean ruleAnomaly) { this.ruleAnomaly = ruleAnomaly; }

    public com.fasterxml.jackson.databind.JsonNode getRuleReasons() { return ruleReasons; }
    public void setRuleReasons(com.fasterxml.jackson.databind.JsonNode ruleReasons) { this.ruleReasons = ruleReasons; }

    public Boolean getHasStepError() { return hasStepError; }
    public void setHasStepError(Boolean hasStepError) { this.hasStepError = hasStepError; }

    public Integer getNStepErrors() { return nStepErrors; }
    public void setNStepErrors(Integer nStepErrors) { this.nStepErrors = nStepErrors; }

    public Integer getWindowDays() { return windowDays; }
    public void setWindowDays(Integer windowDays) { this.windowDays = windowDays; }

    public Double getEwmaRatio() { return ewmaRatio; }
    public void setEwmaRatio(Double ewmaRatio) { this.ewmaRatio = ewmaRatio; }

    public Double getRateRatio() { return rateRatio; }
    public void setRateRatio(Double rateRatio) { this.rateRatio = rateRatio; }

    public Double getBurstiness() { return burstiness; }
    public void setBurstiness(Double burstiness) { this.burstiness = burstiness; }

    public Integer getHawkesScore() { return hawkesScore; }
    public void setHawkesScore(Integer hawkesScore) { this.hawkesScore = hawkesScore; }

    public String getConfidence() { return confidence; }
    public void setConfidence(String confidence) { this.confidence = confidence; }

    public String getSeverity() { return severity; }
    public void setSeverity(String severity) { this.severity = severity; }
}
