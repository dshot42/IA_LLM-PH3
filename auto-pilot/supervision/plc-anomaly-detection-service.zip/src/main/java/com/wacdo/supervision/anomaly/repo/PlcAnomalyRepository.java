package com.wacdo.supervision.anomaly.repo;

import com.wacdo.supervision.anomaly.entity.PlcAnomaly;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.OffsetDateTime;
import java.util.List;

public interface PlcAnomalyRepository extends JpaRepository<PlcAnomaly, Long> {

    @Query("select a.tsDetected from PlcAnomaly a " +
           "where a.machine = :machine and a.stepId = :stepId and a.tsDetected >= :since " +
           "order by a.tsDetected desc")
    List<OffsetDateTime> findRecentDetections(@Param("machine") String machine,
                                             @Param("stepId") String stepId,
                                             @Param("since") OffsetDateTime since);
}
