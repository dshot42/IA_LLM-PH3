package com.wacdo.supervision.anomaly.repo;

import com.wacdo.supervision.workflow.ProductionStep;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductionStepRepository extends JpaRepository<ProductionStep, Long> {

    @Query("select ps from ProductionStep ps join fetch ps.machine m order by m.code asc, ps.sequenceOrder asc")
    List<ProductionStep> loadNominalWorkflow();
}
