package com.wacdo.supervision.anomaly.rules;

import com.fasterxml.jackson.databind.JsonNode;

public record RuleHit(
        String ruleCode,
        String message,
        JsonNode details
) {}
