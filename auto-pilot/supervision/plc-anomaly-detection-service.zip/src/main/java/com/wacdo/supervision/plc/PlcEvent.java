package com.wacdo.supervision.plc;

import java.time.OffsetDateTime;

public class PlcEvent {
    private Long id;
    private OffsetDateTime ts;
    private String machine;
    private String stepId;
    private String stepName;
    private String level;
    private String code;
    private String partId;
    private Integer cycle;

    public Long getId() { return id; }
    public OffsetDateTime getTs() { return ts; }
    public String getMachine() { return machine; }
    public String getStepId() { return stepId; }
    public String getStepName() { return stepName; }
    public String getLevel() { return level; }
    public String getCode() { return code; }
    public String getPartId() { return partId; }
    public Integer getCycle() { return cycle; }

    public void setId(Long id) { this.id = id; }
    public void setTs(OffsetDateTime ts) { this.ts = ts; }
    public void setMachine(String machine) { this.machine = machine; }
    public void setStepId(String stepId) { this.stepId = stepId; }
    public void setStepName(String stepName) { this.stepName = stepName; }
    public void setLevel(String level) { this.level = level; }
    public void setCode(String code) { this.code = code; }
    public void setPartId(String partId) { this.partId = partId; }
    public void setCycle(Integer cycle) { this.cycle = cycle; }
}
