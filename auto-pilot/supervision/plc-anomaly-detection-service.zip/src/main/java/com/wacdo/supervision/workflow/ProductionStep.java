package com.wacdo.supervision.workflow;

public class ProductionStep {
    private Long id;
    private String stepCode;
    private String name;
    private Double nominalDurationS;
    private Integer sequenceOrder;
    private Machine machine;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getStepCode() { return stepCode; }
    public void setStepCode(String stepCode) { this.stepCode = stepCode; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Double getNominalDurationS() { return nominalDurationS; }
    public void setNominalDurationS(Double nominalDurationS) { this.nominalDurationS = nominalDurationS; }

    public Integer getSequenceOrder() { return sequenceOrder; }
    public void setSequenceOrder(Integer sequenceOrder) { this.sequenceOrder = sequenceOrder; }

    public Machine getMachine() { return machine; }
    public void setMachine(Machine machine) { this.machine = machine; }
}
