# Flask + SQLAlchemy – PLC / MES / TimescaleDB

Ce projet contient :
- models (ORM)
- repositories (CRUD)
- routes REST
pour **chaque table** de ton schéma.

⚠️ Les vues, hypertables et continuous aggregates sont gérées via SQL.
