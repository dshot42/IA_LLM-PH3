from app import db

class BaseRepository:
    model = None

    def get_all(self):
        return self.model.query.all()

    def get_by_id(self, id):
        return self.model.query.get(id)

    def create(self, data):
        obj = self.model(**data)
        db.session.add(obj)
        db.session.commit()
        return obj

    def delete(self, id):
        obj = self.get_by_id(id)
        if obj:
            db.session.delete(obj)
            db.session.commit()
        return obj
