from app.models import IndustrialLine
from .base_repository import BaseRepository

class IndustrialLineRepository(BaseRepository):
    model = IndustrialLine
