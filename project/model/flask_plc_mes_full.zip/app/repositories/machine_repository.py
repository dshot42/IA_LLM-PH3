from app.models import Machine
from .base_repository import BaseRepository

class MachineRepository(BaseRepository):
    model = Machine
