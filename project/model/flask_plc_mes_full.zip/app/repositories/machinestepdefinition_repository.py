from app.models import MachineStepDefinition
from .base_repository import BaseRepository

class MachineStepDefinitionRepository(BaseRepository):
    model = MachineStepDefinition
