from app.models import MachineStepExecution
from .base_repository import BaseRepository

class MachineStepExecutionRepository(BaseRepository):
    model = MachineStepExecution
