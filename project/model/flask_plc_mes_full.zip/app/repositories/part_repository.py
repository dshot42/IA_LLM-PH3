from app.models import Part
from .base_repository import BaseRepository

class PartRepository(BaseRepository):
    model = Part
