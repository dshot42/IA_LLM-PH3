from app.models import PartStepExecution
from .base_repository import BaseRepository

class PartStepExecutionRepository(BaseRepository):
    model = PartStepExecution
