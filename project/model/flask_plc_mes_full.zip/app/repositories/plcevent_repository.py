from app.models import PlcEvent
from .base_repository import BaseRepository

class PlcEventRepository(BaseRepository):
    model = PlcEvent
