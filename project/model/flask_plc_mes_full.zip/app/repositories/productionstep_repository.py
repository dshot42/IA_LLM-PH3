from app.models import ProductionStep
from .base_repository import BaseRepository

class ProductionStepRepository(BaseRepository):
    model = ProductionStep
