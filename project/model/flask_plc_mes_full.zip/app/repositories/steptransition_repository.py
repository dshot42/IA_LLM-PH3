from app.models import StepTransition
from .base_repository import BaseRepository

class StepTransitionRepository(BaseRepository):
    model = StepTransition
