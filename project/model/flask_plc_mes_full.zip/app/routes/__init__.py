from flask import Blueprint
from .crud_routes import generate_crud

def register_routes(app):
    generate_crud(app)
