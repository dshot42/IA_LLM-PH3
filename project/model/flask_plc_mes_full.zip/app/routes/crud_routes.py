from flask import request, jsonify
from app.repositories import *

def generate_crud(app):
    repos = {
        "plc_events": PlcEventRepository(),
        "industrial_lines": IndustrialLineRepository(),
        "machines": MachineRepository(),
        "production_steps": ProductionStepRepository(),
        "step_transitions": StepTransitionRepository(),
        "parts": PartRepository(),
        "part_step_executions": PartStepExecutionRepository(),
        "machine_step_definitions": MachineStepDefinitionRepository(),
        "machine_step_executions": MachineStepExecutionRepository(),
    }

    for name, repo in repos.items():

        @app.route(f"/api/{name}", methods=["GET","POST"], endpoint=f"{name}_list")
        def list_create(repo=repo):
            if request.method == "GET":
                return jsonify([r.__dict__ for r in repo.get_all()])
            data = request.json
            obj = repo.create(data)
            return jsonify(obj.__dict__)

        @app.route(f"/api/{name}/<int:id>", methods=["GET","DELETE"], endpoint=f"{name}_detail")
        def detail_delete(id, repo=repo):
            if request.method == "GET":
                obj = repo.get_by_id(id)
                return jsonify(obj.__dict__ if obj else {})
            repo.delete(id)
            return jsonify({"status":"deleted"})
