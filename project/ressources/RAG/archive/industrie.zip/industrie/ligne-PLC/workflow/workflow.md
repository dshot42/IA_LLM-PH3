# Workflow industriel - Ligne de production PLC

## Machine 1 : Préparation
- Étape 1.1 : Chargement matières premières
- Étape 1.2 : Dosage automatique
- Étape 1.3 : Mélange initial
- Étape 1.4 : Transfert vers Machine 2

## Machine 2 : Transformation*
- Étape 2.1 : Réception du lot
- Étape 2.2 : Chauffage
- Étape 2.3 : Refroidissement
- Étape 2.4 : Contrôle qualité
- Étape 2.5 : Transfert vers Machine 3

## Machine 3 : Conditionnement
- Étape 3.1 : Réception du lot
- Étape 3.2 : Remplissage
- Étape 3.3 : Scellage
- Étape 3.4 : Étiquetage
- Étape 3.5 : Palettisation