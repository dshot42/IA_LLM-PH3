Pack ligne industrielle 5 machines

- workflow.json : description complète de la ligne, workflow, grafcet, docs machines.
- advanced_simulator.py : simulateur multithread basé sur le JSON, avec 4 scénarios:
    * nominal     : fonctionnement normal
    * anomalies   : erreurs simulées
    * dephasage   : déphasage progressif entre steps
    * trs_stop    : arrêt machine & chute TRS

Le simulateur:
- lit workflow.json
- crée un thread par machine
- écrit les événements dans:
    * events.log    (texte)
    * events.jsonl  (JSONL, une ligne par événement)

Pour activer un vrai serveur OPC UA:
- installer python-opcua :  pip install opcua
- adapter la fonction setup_opcua_server() et la démarrer dans main().
