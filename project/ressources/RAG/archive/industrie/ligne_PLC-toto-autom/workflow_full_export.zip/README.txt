CONTENU DU ZIP
- workflow_detailed.txt
- synchronization.txt
- doc_M1_Convoyeur.txt ... doc_M7_Palettisation.txt
- logs_full.txt (100 cycles, événements datés, anomalies insérées)
- grafcet.txt (textual representation)
