from flask import Flask
from flask_socketio import SocketIO
from .routes import api_bp
from .ws import init_socketio

socketio = SocketIO(cors_allowed_origins="*", async_mode="eventlet")

def create_app():
    app = Flask(__name__)
    app.register_blueprint(api_bp)
    init_socketio(socketio)
    return app
